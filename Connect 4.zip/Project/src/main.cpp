#include "engine.hpp"

int main() {
    Engine engine;
    engine.run();
}