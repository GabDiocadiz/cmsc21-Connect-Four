enum GameState {
    start,
    how,
    leaderboard,
    modeSelect,
    playerSelect,
    playerSelect1,
    playerSelect2,
    game,
    finish
};