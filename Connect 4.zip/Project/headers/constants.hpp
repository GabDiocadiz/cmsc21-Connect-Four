/* WINDOW PROPERTIES */
#define WINDOW_NAME "Connect Four!"
#define WINDOW_WIDTH 1080
#define WINDOW_HEIGHT 720
